# Store Rating Platform - Backend Documentation

## Spring Boot API Specification

### Technology Stack
- **Backend**: Spring Boot 3.x
- **Database**: MySQL 8.x
- **Security**: Spring Security + JWT
- **Build**: Maven/Gradle

---

## MySQL Database Schema

```sql
-- Users table
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(60) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    address VARCHAR(400) NOT NULL,
    role ENUM('ADMIN', 'USER', 'STORE_OWNER') NOT NULL DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Stores table
CREATE TABLE stores (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(60) NOT NULL,
    email VARCHAR(255) NOT NULL,
    address VARCHAR(400) NOT NULL,
    owner_id BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id)
);

-- Ratings table
CREATE TABLE ratings (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    store_id BIGINT NOT NULL,
    rating TINYINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_store (user_id, store_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (store_id) REFERENCES stores(id)
);

-- Indexes for performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_stores_owner ON stores(owner_id);
CREATE INDEX idx_ratings_store ON ratings(store_id);
CREATE INDEX idx_ratings_user ON ratings(user_id);
```

---

## REST API Endpoints

### Authentication

| Method | Endpoint | Description | Body |
|--------|----------|-------------|------|
| POST | `/api/auth/login` | Login | `{email, password}` |
| POST | `/api/auth/signup` | Register user | `{name, email, password, address}` |
| PUT | `/api/auth/password` | Change password | `{currentPassword, newPassword}` |

### Users (Admin only)

| Method | Endpoint | Description | Params |
|--------|----------|-------------|--------|
| GET | `/api/users` | List users | `page, size, sortBy, sortDir, name, email, address, role` |
| GET | `/api/users/{id}` | Get user details | - |
| POST | `/api/users` | Create user | `{name, email, password, address, role}` |

### Stores

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/stores` | List stores | All authenticated |
| GET | `/api/stores/{id}` | Get store details | All authenticated |
| POST | `/api/stores` | Create store | Admin only |

### Ratings

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/stores/{id}/ratings` | Get store ratings | Store owner |
| POST | `/api/stores/{id}/ratings` | Submit rating | Users |
| PUT | `/api/stores/{id}/ratings` | Update rating | Users |

### Dashboard

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/api/dashboard/stats` | Get stats | Admin |
| GET | `/api/dashboard/store-owner` | Store owner stats | Store owner |

---

## Sample Spring Boot Entity

```java
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, length = 60)
    @Size(min = 20, max = 60)
    private String name;
    
    @Column(nullable = false, unique = true)
    @Email
    private String email;
    
    @Column(nullable = false)
    private String password;
    
    @Column(nullable = false, length = 400)
    @Size(max = 400)
    private String address;
    
    @Enumerated(EnumType.STRING)
    private Role role = Role.USER;
}
```

---

## Frontend API Service (Ready to Connect)

The React frontend uses TypeScript interfaces in `src/types/index.ts` that match the API responses. Replace mock data in `src/lib/mock-data.ts` with actual API calls using the service layer pattern.

## Validation Rules (Implemented in Frontend)
- **Name**: 20-60 characters
- **Email**: Valid email format
- **Password**: 8-16 chars, 1 uppercase, 1 special character
- **Address**: Max 400 characters
- **Rating**: 1-5
