import { useMemo } from 'react';
import { Star, Users as UsersIcon } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import DashboardLayout from '@/components/DashboardLayout';
import { StarRating } from '@/components/StarRating';
import { useAuth } from '@/context/AuthContext';
import { mockRatings, mockStores } from '@/lib/mock-data';

export default function StoreOwnerDashboard() {
  const { user } = useAuth();

  // Get stores owned by current user
  const ownedStores = useMemo(() => {
    return mockStores.filter(store => store.ownerId === user?.id);
  }, [user?.id]);

  // Get ratings for owned stores
  const storeRatings = useMemo(() => {
    const storeIds = ownedStores.map(s => s.id);
    return mockRatings.filter(r => storeIds.includes(r.storeId));
  }, [ownedStores]);

  // Calculate average rating across all stores
  const averageRating = useMemo(() => {
    if (storeRatings.length === 0) return 0;
    const total = storeRatings.reduce((sum, r) => sum + r.rating, 0);
    return total / storeRatings.length;
  }, [storeRatings]);

  return (
    <DashboardLayout>
      <div className="p-6 lg:p-8 space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Store Dashboard</h1>
          <p className="text-muted-foreground mt-1">View your store's performance and customer ratings</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="dashboard-card stat-card-stores">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Your Stores</CardTitle>
              <Star className="w-5 h-5 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{ownedStores.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Registered stores</p>
            </CardContent>
          </Card>

          <Card className="dashboard-card stat-card-ratings">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Average Rating</CardTitle>
              <Star className="w-5 h-5 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold text-foreground">
                  {averageRating.toFixed(1)}
                </span>
                <StarRating rating={averageRating} size="sm" />
              </div>
              <p className="text-xs text-muted-foreground mt-1">Based on {storeRatings.length} ratings</p>
            </CardContent>
          </Card>

          <Card className="dashboard-card stat-card-users">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Reviews</CardTitle>
              <UsersIcon className="w-5 h-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{storeRatings.length}</div>
              <p className="text-xs text-muted-foreground mt-1">Customer ratings received</p>
            </CardContent>
          </Card>
        </div>

        {/* Store Performance */}
        {ownedStores.map((store) => {
          const ratings = mockRatings.filter(r => r.storeId === store.id);
          return (
            <Card key={store.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{store.name}</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">{store.address}</p>
                  </div>
                  <div className="text-right">
                    <StarRating rating={store.averageRating} showValue />
                    <p className="text-xs text-muted-foreground mt-1">
                      {store.totalRatings} total ratings
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <h4 className="font-medium mb-4">Recent Ratings</h4>
                {ratings.length > 0 ? (
                  <div className="rounded-lg border overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-muted/50">
                          <TableHead>User</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Rating</TableHead>
                          <TableHead>Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {ratings.map((rating) => (
                          <TableRow key={rating.id} className="table-row-hover">
                            <TableCell className="font-medium">{rating.userName}</TableCell>
                            <TableCell>{rating.userEmail}</TableCell>
                            <TableCell>
                              <StarRating rating={rating.rating} size="sm" />
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {new Date(rating.createdAt).toLocaleDateString()}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">
                    No ratings yet for this store
                  </p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </DashboardLayout>
  );
}
