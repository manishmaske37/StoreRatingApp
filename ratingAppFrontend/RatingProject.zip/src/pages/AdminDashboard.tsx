import { useState, useMemo } from 'react';
import { Users, Building2, Star, Plus, ArrowUpDown, Search, Eye } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import DashboardLayout from '@/components/DashboardLayout';
import { StarRating } from '@/components/StarRating';
import { AddUserForm } from '@/components/forms/AddUserForm';
import { AddStoreForm } from '@/components/forms/AddStoreForm';
import { mockUsers, mockStores, mockRatings, mockDashboardStats } from '@/lib/mock-data';
import { User, UserRole } from '@/types';

type SortField = 'name' | 'email' | 'address' | 'role';
type SortDir = 'asc' | 'desc';

export default function AdminDashboard() {
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<string>('all');
  const [userSortField, setUserSortField] = useState<SortField>('name');
  const [userSortDir, setUserSortDir] = useState<SortDir>('asc');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [addStoreOpen, setAddStoreOpen] = useState(false);

  // Filter and sort users
  const filteredUsers = useMemo(() => {
    let result = [...mockUsers];

    // Filter by search
    if (userSearch) {
      const search = userSearch.toLowerCase();
      result = result.filter(
        (u) =>
          u.name.toLowerCase().includes(search) ||
          u.email.toLowerCase().includes(search) ||
          u.address.toLowerCase().includes(search)
      );
    }

    // Filter by role
    if (userRoleFilter !== 'all') {
      result = result.filter((u) => u.role === userRoleFilter);
    }

    // Sort
    result.sort((a, b) => {
      const aVal = a[userSortField] || '';
      const bVal = b[userSortField] || '';
      const comparison = aVal.toString().localeCompare(bVal.toString());
      return userSortDir === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [userSearch, userRoleFilter, userSortField, userSortDir]);

  const toggleSort = (field: SortField) => {
    if (userSortField === field) {
      setUserSortDir(userSortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setUserSortField(field);
      setUserSortDir('asc');
    }
  };

  const getRoleBadgeVariant = (role: UserRole) => {
    switch (role) {
      case 'ADMIN':
        return 'default';
      case 'STORE_OWNER':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6 lg:p-8 space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">Manage users, stores, and view platform statistics</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="dashboard-card stat-card-users">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
              <Users className="w-5 h-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{mockDashboardStats.totalUsers}</div>
              <p className="text-xs text-muted-foreground mt-1">Registered accounts</p>
            </CardContent>
          </Card>

          <Card className="dashboard-card stat-card-stores">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Stores</CardTitle>
              <Building2 className="w-5 h-5 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{mockDashboardStats.totalStores}</div>
              <p className="text-xs text-muted-foreground mt-1">Registered stores</p>
            </CardContent>
          </Card>

          <Card className="dashboard-card stat-card-ratings">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Ratings</CardTitle>
              <Star className="w-5 h-5 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{mockDashboardStats.totalRatings}</div>
              <p className="text-xs text-muted-foreground mt-1">Submitted ratings</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-4">
          <Dialog open={addUserOpen} onOpenChange={setAddUserOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add User
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Add New User</DialogTitle>
                <DialogDescription>Create a new user account</DialogDescription>
              </DialogHeader>
              <AddUserForm onSuccess={() => setAddUserOpen(false)} />
            </DialogContent>
          </Dialog>

          <Dialog open={addStoreOpen} onOpenChange={setAddStoreOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Store
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Store</DialogTitle>
                <DialogDescription>Register a new store on the platform</DialogDescription>
              </DialogHeader>
              <AddStoreForm onSuccess={() => setAddStoreOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Users Table */}
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <CardTitle>Users</CardTitle>
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search users..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="pl-9 w-full sm:w-64"
                  />
                </div>
                <Select value={userRoleFilter} onValueChange={setUserRoleFilter}>
                  <SelectTrigger className="w-full sm:w-40">
                    <SelectValue placeholder="Filter by role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    <SelectItem value="ADMIN">Admin</SelectItem>
                    <SelectItem value="USER">User</SelectItem>
                    <SelectItem value="STORE_OWNER">Store Owner</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSort('name')}
                        className="-ml-3"
                      >
                        Name
                        <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSort('email')}
                        className="-ml-3"
                      >
                        Email
                        <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead className="hidden md:table-cell">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSort('address')}
                        className="-ml-3"
                      >
                        Address
                        <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSort('role')}
                        className="-ml-3"
                      >
                        Role
                        <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead className="w-20">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id} className="table-row-hover">
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell className="hidden md:table-cell max-w-xs truncate">
                        {user.address}
                      </TableCell>
                      <TableCell>
                        <Badge variant={getRoleBadgeVariant(user.role)}>
                          {user.role.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => setSelectedUser(user)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>User Details</DialogTitle>
                            </DialogHeader>
                            {selectedUser && (
                              <div className="space-y-4">
                                <div>
                                  <label className="text-sm font-medium text-muted-foreground">Name</label>
                                  <p className="text-foreground">{selectedUser.name}</p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-muted-foreground">Email</label>
                                  <p className="text-foreground">{selectedUser.email}</p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-muted-foreground">Address</label>
                                  <p className="text-foreground">{selectedUser.address}</p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-muted-foreground">Role</label>
                                  <p className="text-foreground">
                                    <Badge variant={getRoleBadgeVariant(selectedUser.role)}>
                                      {selectedUser.role.replace('_', ' ')}
                                    </Badge>
                                  </p>
                                </div>
                                {selectedUser.role === 'STORE_OWNER' && selectedUser.rating && (
                                  <div>
                                    <label className="text-sm font-medium text-muted-foreground">Store Rating</label>
                                    <div className="mt-1">
                                      <StarRating rating={selectedUser.rating} showValue />
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
