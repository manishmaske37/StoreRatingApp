import { useState, useMemo } from 'react';
import { Plus, Search, ArrowUpDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import DashboardLayout from '@/components/DashboardLayout';
import { StarRating } from '@/components/StarRating';
import { AddStoreForm } from '@/components/forms/AddStoreForm';
import { mockStores } from '@/lib/mock-data';

type SortField = 'name' | 'email' | 'address' | 'averageRating';
type SortDir = 'asc' | 'desc';

export default function StoresPage() {
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [addStoreOpen, setAddStoreOpen] = useState(false);

  const filteredStores = useMemo(() => {
    let result = [...mockStores];

    if (search) {
      const searchLower = search.toLowerCase();
      result = result.filter(
        (s) =>
          s.name.toLowerCase().includes(searchLower) ||
          s.email.toLowerCase().includes(searchLower) ||
          s.address.toLowerCase().includes(searchLower)
      );
    }

    result.sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
      }
      const comparison = String(aVal).localeCompare(String(bVal));
      return sortDir === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [search, sortField, sortDir]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6 lg:p-8 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Stores</h1>
            <p className="text-muted-foreground mt-1">Manage all registered stores</p>
          </div>
          <Dialog open={addStoreOpen} onOpenChange={setAddStoreOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Store
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Store</DialogTitle>
                <DialogDescription>Register a new store on the platform</DialogDescription>
              </DialogHeader>
              <AddStoreForm onSuccess={() => setAddStoreOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, email, or address..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 max-w-md"
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>
                      <Button variant="ghost" size="sm" onClick={() => toggleSort('name')} className="-ml-3">
                        Name <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead>
                      <Button variant="ghost" size="sm" onClick={() => toggleSort('email')} className="-ml-3">
                        Email <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead className="hidden md:table-cell">
                      <Button variant="ghost" size="sm" onClick={() => toggleSort('address')} className="-ml-3">
                        Address <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead>
                      <Button variant="ghost" size="sm" onClick={() => toggleSort('averageRating')} className="-ml-3">
                        Rating <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStores.map((store) => (
                    <TableRow key={store.id} className="table-row-hover">
                      <TableCell className="font-medium">{store.name}</TableCell>
                      <TableCell>{store.email}</TableCell>
                      <TableCell className="hidden md:table-cell max-w-xs truncate">{store.address}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <StarRating rating={store.averageRating} size="sm" />
                          <span className="text-sm text-muted-foreground">({store.totalRatings})</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
