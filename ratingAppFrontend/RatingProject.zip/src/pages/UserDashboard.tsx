import { useState, useMemo } from 'react';
import { Search, ArrowUpDown, Star } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import DashboardLayout from '@/components/DashboardLayout';
import { StarRating } from '@/components/StarRating';
import { mockStores } from '@/lib/mock-data';
import { Store } from '@/types';
import { useToast } from '@/hooks/use-toast';

type SortField = 'name' | 'email' | 'address' | 'averageRating';
type SortDir = 'asc' | 'desc';

export default function UserDashboard() {
  const { toast } = useToast();
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [ratingStore, setRatingStore] = useState<Store | null>(null);
  const [tempRating, setTempRating] = useState(0);
  const [userRatings, setUserRatings] = useState<Record<number, number>>({
    1: 5, // Pre-filled demo rating for store 1
    2: 4, // Pre-filled demo rating for store 2
  });

  // Filter and sort stores
  const filteredStores = useMemo(() => {
    let result = [...mockStores].map(store => ({
      ...store,
      userRating: userRatings[store.id],
    }));

    // Filter by search
    if (search) {
      const searchLower = search.toLowerCase();
      result = result.filter(
        (s) =>
          s.name.toLowerCase().includes(searchLower) ||
          s.address.toLowerCase().includes(searchLower)
      );
    }

    // Sort
    result.sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
      }
      const comparison = String(aVal).localeCompare(String(bVal));
      return sortDir === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [search, sortField, sortDir, userRatings]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const handleOpenRating = (store: Store) => {
    setRatingStore(store);
    setTempRating(userRatings[store.id] || 0);
  };

  const handleSubmitRating = () => {
    if (ratingStore && tempRating > 0) {
      setUserRatings(prev => ({
        ...prev,
        [ratingStore.id]: tempRating,
      }));
      toast({
        title: 'Rating Submitted',
        description: `You rated ${ratingStore.name} ${tempRating} stars`,
      });
      setRatingStore(null);
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6 lg:p-8 space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Browse Stores</h1>
          <p className="text-muted-foreground mt-1">Discover and rate stores in your area</p>
        </div>

        {/* Stores Table */}
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <CardTitle>All Stores</CardTitle>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or address..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 w-full sm:w-80"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSort('name')}
                        className="-ml-3"
                      >
                        Store Name
                        <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead className="hidden md:table-cell">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSort('address')}
                        className="-ml-3"
                      >
                        Address
                        <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleSort('averageRating')}
                        className="-ml-3"
                      >
                        Overall Rating
                        <ArrowUpDown className="w-4 h-4 ml-2" />
                      </Button>
                    </TableHead>
                    <TableHead>Your Rating</TableHead>
                    <TableHead className="w-28">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStores.map((store) => (
                    <TableRow key={store.id} className="table-row-hover">
                      <TableCell className="font-medium">{store.name}</TableCell>
                      <TableCell className="hidden md:table-cell max-w-xs truncate">
                        {store.address}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <StarRating rating={store.averageRating} size="sm" />
                          <span className="text-sm text-muted-foreground">
                            ({store.totalRatings})
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {store.userRating ? (
                          <StarRating rating={store.userRating} size="sm" />
                        ) : (
                          <span className="text-sm text-muted-foreground">Not rated</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant={store.userRating ? 'outline' : 'default'}
                              size="sm"
                              onClick={() => handleOpenRating(store)}
                            >
                              <Star className="w-4 h-4 mr-1" />
                              {store.userRating ? 'Modify' : 'Rate'}
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Rate Store</DialogTitle>
                              <DialogDescription>{ratingStore?.name}</DialogDescription>
                            </DialogHeader>
                            <div className="py-6">
                              <div className="flex flex-col items-center gap-4">
                                <p className="text-sm text-muted-foreground">
                                  Click on the stars to rate
                                </p>
                                <StarRating
                                  rating={tempRating}
                                  size="lg"
                                  interactive
                                  onRatingChange={setTempRating}
                                />
                                <p className="text-2xl font-bold">
                                  {tempRating > 0 ? `${tempRating}/5` : 'Select rating'}
                                </p>
                              </div>
                            </div>
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="outline"
                                onClick={() => setRatingStore(null)}
                              >
                                Cancel
                              </Button>
                              <Button
                                onClick={handleSubmitRating}
                                disabled={tempRating === 0}
                              >
                                Submit Rating
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
