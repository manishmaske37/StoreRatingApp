// User roles
export type UserRole = 'ADMIN' | 'USER' | 'STORE_OWNER';

// User interface
export interface User {
  id: number;
  name: string;
  email: string;
  address: string;
  role: UserRole;
  createdAt: string;
  rating?: number; // Only for store owners
}

// Store interface
export interface Store {
  id: number;
  name: string;
  email: string;
  address: string;
  ownerId: number;
  ownerName: string;
  averageRating: number;
  totalRatings: number;
  userRating?: number; // Current user's rating for this store
}

// Rating interface
export interface Rating {
  id: number;
  userId: number;
  userName: string;
  userEmail: string;
  storeId: number;
  storeName: string;
  rating: number;
  createdAt: string;
  updatedAt: string;
}

// Dashboard stats
export interface DashboardStats {
  totalUsers: number;
  totalStores: number;
  totalRatings: number;
}

// Auth types
export interface LoginCredentials {
  email: string;
  password: string;
}

export interface SignupData {
  name: string;
  email: string;
  address: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

// API response wrapper
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  errors?: Record<string, string>;
}

// Pagination
export interface PaginatedResponse<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
  totalPages: number;
}

// Filter/Sort params
export interface ListParams {
  page?: number;
  size?: number;
  sortBy?: string;
  sortDir?: 'asc' | 'desc';
  search?: string;
  name?: string;
  email?: string;
  address?: string;
  role?: UserRole;
}
